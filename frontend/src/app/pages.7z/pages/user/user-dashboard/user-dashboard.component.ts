import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {

  // qid: any;
  // questions: any;

  // marksGot = 0;
  // correctAnswers = 0;
  // attempted = 0;

  // isSubmit = false;
  // timer: any;

  // blinkFlag = false;

  // records variables and objects
  // record: any;
  // quiz: any;
  // user: any;

  constructor() { }

  ngOnInit(): void {
  }

}
